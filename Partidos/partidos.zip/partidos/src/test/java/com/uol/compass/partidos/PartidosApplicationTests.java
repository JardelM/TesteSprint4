package com.uol.compass.partidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartidosApplicationTests {

	@Test
	void contextLoads() {
	}

}
